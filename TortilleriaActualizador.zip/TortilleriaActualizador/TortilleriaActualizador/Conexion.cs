﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using MySql.Data.MySqlClient;

namespace TortilleriaActualizador
{
    class Conexion
    {

        public static MySqlConnection obtenerConexion()
        {
            MySqlConnection conexion = new MySqlConnection("server=127.0.0.1; database=casartgo_reg; Uid=root; pwd=RamonGarcia21");
            conexion.Open();
            return conexion;
        }
    }
}
