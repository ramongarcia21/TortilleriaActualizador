﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Data;


namespace TortilleriaActualizador
{

    class DetalleTicket
    {


        public int Orden { set; get; }

        public System.DateTime FechaVenta { set; get; }

        public int IdProducto { set; get; }

        public string Descripcion { set; get; }

        public string Medida { set; get; }

        public decimal Precio { set; get; }


    }

   
}
